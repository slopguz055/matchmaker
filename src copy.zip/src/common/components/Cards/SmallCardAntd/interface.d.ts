export interface SmallCardAntdProps {
  game: string;
  alt: string;
  src: string;
  user: string;
  desc: string;
}
