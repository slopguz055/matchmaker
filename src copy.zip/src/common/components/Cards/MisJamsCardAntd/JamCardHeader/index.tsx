// JamCardHeader.tsx
"use client";

import React from "react";
import { Avatar, Typography, Tag } from "antd";
import {
  CalendarOutlined,
  ClockCircleOutlined,
  UserOutlined,
} from "@ant-design/icons";

const { Title, Text, Paragraph } = Typography;

interface Props {
  avatar: string;
  description: string;
  jamDate: string;
  jamTime: string;
  maxPlayers: number;
  playersCount: number;
  jamTitle: string;
  gameTitle: string;
}

const JamCardHeader: React.FC<Props> = ({
  avatar,
  description,
  jamDate,
  jamTime,
  maxPlayers,
  playersCount,
  jamTitle,
  gameTitle,
}) => {
  console.log("JamTitle: " + jamTitle);
  console.log("JamTime: " + jamTime);
  console.log("JamDate: " + jamDate);
  return (
    <div className="space-y-2">
      {/* Título del juego */}
      <Title level={3} className="text-center text-blue-700">
        {gameTitle}
      </Title>

      {/* Avatar + Título de la Jam */}
      <div className="flex items-center gap-3">
        <Avatar size={40} src={avatar} />
        <Title level={4} className="mb-0">
          {jamTitle}
        </Title>
      </div>

      {/* Descripción */}
      <Paragraph className="text-gray-700" ellipsis={{ rows: 2 }}>
        {description}
      </Paragraph>

      {/* Fecha y hora */}
      <div className="flex items-center gap-3 text-gray-500 text-sm">
        <CalendarOutlined />
        <Text>{jamDate}</Text>
        <ClockCircleOutlined />
        <Text>{jamTime}</Text>
      </div>

      {/* Participantes */}
      <div className="flex items-center gap-2 text-sm mt-1">
        <UserOutlined />
        <Tag color="blue">
          {playersCount}/{maxPlayers} jugadores
        </Tag>
      </div>
    </div>
  );
};

export default JamCardHeader;
