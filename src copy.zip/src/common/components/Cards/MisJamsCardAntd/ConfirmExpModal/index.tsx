import React from "react";
import { DeleteOutlined } from "@ant-design/icons";
import ConfirmModalAntd from "@/common/components/Modals/ConfirmModalAntd/Delivery";

interface ConfirmExpelModalProps {
  visible: boolean;
  loading: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}

const ConfirmExpelModal: React.FC<ConfirmExpelModalProps> = ({
  visible,
  loading,
  onCancel,
  onConfirm,
}) => (
  <ConfirmModalAntd
    title="¿Expulsar jugador/a?"
    icon={<DeleteOutlined className="text-4xl" />}
    message="¿Estás seguro/a de que quieres expulsar a este jugador/a?"
    open={visible}
    confirmLoading={loading}
    onCancel={onCancel}
    onConfirm={onConfirm}
  />
);

export default ConfirmExpelModal;
