import { User } from "@/common/types/utility";
import { Avatar, Card, Typography, Tag, Button } from "antd";

const { Title } = Typography;

type Props = {
  user: User;
  profileUrl?: string;
};

export default function PerfilCardAntd({ user, profileUrl }: Props) {
  const steamProfileUrl =
    profileUrl ?? `https://steamcommunity.com/profiles/${user.steamId}`;

  return (
    <Card className="bg-[#181E2C] text-white rounded-xl">
      <div className="flex items-center gap-4 mb-4">
        <Avatar size={80} src={user.avatar} />
        <div>
          <Title level={1} className="text-accent m-0">
            {user.name}
          </Title>
          <Tag color="geekblue" className="mt-1">
            Steam ID: {user.steamId}
          </Tag>
        </div>
      </div>
      <div className="flex justify-end mx-4 mr-4">
        <Button
          type="default"
          href={steamProfileUrl}
          target="_blank"
          rel="noopener noreferrer"
        >
          Ir al perfil de Steam
        </Button>
      </div>
    </Card>
  );
}
