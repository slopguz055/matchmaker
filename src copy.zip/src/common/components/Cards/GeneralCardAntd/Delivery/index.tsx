"use client";

import React from "react";
import { Card, Typography, Button, Space, Image } from "antd";
import { CalendarOutlined, ClockCircleOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import Link from "next/link";
import { Jam, User } from "@/common/types/utility";

const { Title, Text, Paragraph } = Typography;

interface Props {
  jam: Jam;
  currentUser: User | null;
  jwtValid: boolean;
  onJoinLeaveJam: (jam: Jam) => Promise<void>;
}

const GeneralJamCard: React.FC<Props> = ({
  jam,
  currentUser,
  jwtValid,
  onJoinLeaveJam,
}) => {
  const userIsInJam = currentUser
    ? jam.players.some((p) => p.steamId === currentUser.steamId)
    : false;

  const userIsCreator =
    currentUser && currentUser.steamId === jam.createdBy.steamId;

  return (
    <Card hoverable style={{ width: "70vw" }} bodyStyle={{ padding: 0 }}>
      <div className="flex">
        <div className="flex-shrink-0 w-[250px] h-full mr-6">
          <Image
            src={jam.game?.headerImage}
            alt={jam.game?.name}
            width={250}
            height={160}
            style={{ objectFit: "cover", height: "100%" }}
            preview={false}
          />
        </div>
        <div className="flex-1 p-4 flex flex-col justify-between">
          <Space direction="vertical" size="small" className="w-full">
            <Title level={4} className="mb-0">
              {jam.title}
            </Title>
            <Text className="text-gray-700 font-medium flex items-center gap-2">
              <CalendarOutlined />
              {dayjs(jam.jamDate).format("DD/MM/YYYY")}
              <span className="mx-2">-</span>
              <ClockCircleOutlined />
              {jam.jamTime}
            </Text>

            <Paragraph ellipsis={{ rows: 3 }}>{jam.description}</Paragraph>

            <Text>
              <strong>Creador: </strong>
              <Link
                href={jam.createdBy.profileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                {jam.createdBy.name}
              </Link>
            </Text>

            {userIsCreator ? (
              <Button type="default" disabled>
                Eres el/la creador/a de esta Jam
              </Button>
            ) : (
              <Button
                type="primary"
                onClick={() => onJoinLeaveJam(jam)}
                disabled={!jwtValid}
              >
                {jwtValid
                  ? userIsInJam
                    ? "Salir de la Jam"
                    : "Unirse a la Jam"
                  : "Inicia sesión para unirte"}
              </Button>
            )}
          </Space>
        </div>
      </div>
    </Card>
  );
};

export default GeneralJamCard;
