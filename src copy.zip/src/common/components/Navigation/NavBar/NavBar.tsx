// components/NavBar/Delivery.tsx
"use client";

import { FC } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Image, Layout, Menu } from "antd";

import LoginButton from "../../LoginButton/Delivery";
import UserNavAvatar from "../UserNavAvatar/Delivery";
import { useAuth } from "@/common/hooks/useAuth";

const { Header } = Layout;

const navItems = [
  { key: "jams", label: "Jams", href: "/jams" },
  { key: "crear", label: "Crear Jam", href: "/crear-jam" },
  { key: "mis", label: "Mis Jams", href: "/mis-jams" },
  { key: "historial", label: "Historial", href: "/historial" },
];

const NavBar: FC = () => {
  const pathname = usePathname();
  const selectedKey = navItems.find((item) =>
    pathname.startsWith(item.href)
  )?.key;
  const menuItems = navItems.map(({ key, label, href }) => ({
    key,
    label: <Link href={href}>{label}</Link>,
  }));

  const { user, loading } = useAuth();

  return (
    <Header className="bg-primary-dark px-10 shadow-sm h-16 flex items-center relative z-50">
      <div className="flex items-center">
        <Link href="/" className="flex items-center">
          <Image
            src="/mmkr_logov2.png"
            alt="Logo de Matchmaker"
            height={55}
            width={55}
            preview={false}
          />
          <span className="ml-3 text-lg font-bold text-white hover:text-red-400 transition">
            MatchMaKeR
          </span>
        </Link>
      </div>

      <div className="absolute left-1/2 transform -translate-x-1/2">
        <Menu
          mode="horizontal"
          selectedKeys={selectedKey ? [selectedKey] : []}
          items={menuItems}
          className="border-none font-medium text-base bg-transparent"
          overflowedIndicator={null}
        />
      </div>

      <div className="ml-auto flex items-center">
        {loading ? null : user ? (
          <UserNavAvatar user={user} />
        ) : (
          <LoginButton />
        )}
      </div>
    </Header>
  );
};

export default NavBar;
