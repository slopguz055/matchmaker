export type User = {
  id: number;
  steamId: string;
  name: string;
  avatar: string;
};
export type Game = {
  appid: number;
  name: string;
  shortDescription: string;
  categories: string[];
  headerImage: string;
  lastUpdated: string;
};

export type Jam = {
  id: string;
  userId: string;
  gameId: string;
  title: string;
  maxPlayers: number;
  players: User[];
  description: string;
  status: string;
  date: string;
  time: string;
  user?: User;
  game?: Game;
  createdBy: User;
};

export interface JamInputDTO {
  title: string;
  description: string;
  game: Game;
  jamDate: string;
  jamTime: string;
  state: "OPEN" | "FULL" | "FINISHED";
  createdBy: Usuario;
  createdAt: string;
  maxPlayers: number;
  players: Usuario[];
  gameMode: "CASUAL" | "COMPETITIVE" | "COMPLETIST";
  voiceMode: "TEXT" | "HEAR" | "TALK";
  language: "INDEF" | "ES" | "EN" | "FR" | "PT" | "IT";
  duration: "15-30" | "30-60" | "60-120" | "120-180" | "180-240" | "240+";
}
